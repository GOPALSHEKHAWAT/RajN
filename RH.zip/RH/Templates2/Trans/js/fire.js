//login form configuration
$('.message a').click(function(){
   $('form').animate({height: "toggle", opacity: "toggle"}, "slow");
   document.getElementById("danger").style.display = "none";
}); 

 //Firebase
(function(){ 

  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyCrOD_zltR_fVtkEMisb-PwQDbw5fKZmiI",
    authDomain: "transport-1c639.firebaseapp.com",
    databaseURL: "https://transport-1c639.firebaseio.com",
    storageBucket: "transport-1c639.appspot.com",
    messagingSenderId: "386998901801"
  };
  var mainApp = firebase.initializeApp(config);

  const login_email = document.getElementById('login_email');
  const	login_password = document.getElementById('login_password');
  const login_button = document.getElementById('login_button');
  const sign_email = document.getElementById('sign_email');
  const sign_name = document.getElementById('sign_name');
  const	sign_pass = document.getElementById('sign_pass');
  const sign_button = document.getElementById('sign_button');
  
  //Login Process
  login_button.addEventListener('click',e => {
	
	var email = login_email.value;
	var pass = login_password.value;
	
	  mainApp.auth().signInWithEmailAndPassword(email, pass).then(function(){
			//do nothing
	  },function(error) {
		  // Handle Errors here.
		  var errorCode = error.code;
		  var errorMessage = error.message;
		  console.log(errorCode);
		  console.log(errorMessage);
		  document.getElementById("danger").style.display = "block";
		  // ...
	});
  
  });
  
  //SignUp Process
    sign_button.addEventListener('click',e => {
  
	const email = sign_email.value;
	const pass = sign_pass.value;
	const name = sign_name.value;
	
	var user = mainApp.auth().createUserWithEmailAndPassword(email, pass).catch(function(error) {
		  // Handle Errors here.
		  var errorCode = error.code;
		  var errorMessage = error.message;
		  console.log(errorCode);
		  console.log(errorMessage);
		  document.getElementById("danger").style.display = "block";
		  // ...
	});
	
	mainApp.auth().onAuthStateChanged( firebaseUser => {
		if(firebaseUser){
			alert('Hello');
			firebaseUser.updateProfile({
				displayName: name
			});
		}
	});
	
  });

  //Adding State Listener
  mainApp.auth().onAuthStateChanged( firebaseUser => {
	//alert( name );
	if(firebaseUser){
		console.log(firebaseUser);
		window.location.href = "index.html";
		
	}else{
		console.log('Not logged in');
	}
  
  });

}());
//ends 