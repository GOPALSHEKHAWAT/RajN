$('[data-toggle="popover"]').popover({html:true});

  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyCrOD_zltR_fVtkEMisb-PwQDbw5fKZmiI",
    authDomain: "transport-1c639.firebaseapp.com",
    databaseURL: "https://transport-1c639.firebaseio.com",
    storageBucket: "transport-1c639.appspot.com",
    messagingSenderId: "386998901801"
  };
  var mainApp = firebase.initializeApp(config);
  //getting reference to the database service
  var database = firebase.database();
  
  //referencing the html components
  const from_autocomplete = document.getElementById('from_autocomplete');
  const to_autocomplete = document.getElementById('to_autocomplete');
  const trip_date = document.getElementById('trip_date');
  const mode = document.getElementById('mode');
  const calculate = document.getElementById('calculate');
  const	logout = document.getElementById('logout');
  
  //Login Out
  logout.addEventListener('click',e => {
		mainApp.auth().signOut();
		
  });
 
  //Adding State Listener
  mainApp.auth().onAuthStateChanged( firebaseUser => {
  
		if(firebaseUser){
			//do nothing
			console.log(firebaseUser);
			document.getElementById("login_text").textContent = " "+firebaseUser.email;
			
			var userId = firebase.auth().currentUser.uid;
			
			calculate.addEventListener( 'click', writeData => {
				  var postData = {
						from: from_autocomplete.value,
						to: to_autocomplete.value,
						date: trip_date.value,
						mode: mode.value
				  };
				  var newPostKey = database.ref('/users/'+userId).push().key;
				  var updates = {};
				  updates['/trip/' + newPostKey] = postData;
				  firebase.database().ref('/users/'+userId).update(updates);

			});
			
		}
		else{
			window.location.href = "login.html";
		}
  });
//ends 